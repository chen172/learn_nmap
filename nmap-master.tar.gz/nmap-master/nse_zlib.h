#ifndef ZLIB
#define ZLIB

#define NSE_ZLIBNAME "zlib"

LUALIB_API int luaopen_zlib(lua_State *L);

#endif

